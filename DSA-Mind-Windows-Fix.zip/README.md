# DSA Mind — AI-Driven Personalized DSA Learning Assistant

A beginner-friendly DSA learning platform built with React 18, TypeScript, Vite, Tailwind CSS, React Router, Framer Motion, Lucide React and optional Supabase/Gemini integration.

## Included
- Responsive dashboard and local demo login
- Arrays, Strings and Linked Lists
- Five-question timed diagnostic assessments
- Rule-based misconception detection
- Personalized beginner-friendly lessons with offline fallback
- Five-question retests and before/after comparison
- Assessment history and topic progress
- Supabase SQL schema, seed data and Gemini Edge Function

## Requirements
Install Node.js 20 LTS or newer (includes npm) and VS Code. Internet is required for the first dependency installation.

## Windows setup — Command Prompt (CMD)
Open CMD in the folder that contains `package.json`, then run:

```bat
npm install
copy .env.example .env
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

If you are using PowerShell instead, the environment-file command is:

```powershell
Copy-Item .env.example .env
```

Demo mode is the default and does not require API credentials. You can also skip copying `.env.example` for demo mode. Enter a display name to begin; demo data is stored in this browser's local storage.

## Important: folder location
After extracting the ZIP, `package.json` must be directly inside the folder you open in the terminal. If you see another `DSA-Mind` folder inside the extracted folder, open that inner folder instead.

## Supabase setup (optional)
1. Create a Supabase project.
2. Copy the Project URL and anon/public key from Project Settings → API.
3. Put these values in `.env`:

```env
VITE_APP_MODE=connected
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

4. Run `supabase/migrations/001_initial_schema.sql` in the Supabase SQL Editor.
5. Restart the dev server after editing `.env`.

Scope note: the current sign-in is a local demo identity, not Supabase Auth registration/login. Supabase mode persists assessment summaries using the configured client; full account authentication should be added before production deployment.

## Gemini setup (optional)
Gemini requests are handled by the Supabase Edge Function, not directly from browser code. Deploy `supabase/functions/ai-tutor` and set the Gemini API key as a Supabase function secret. See the Supabase Edge Functions documentation for deployment commands. If the function or credentials are unavailable, the app uses its local explanation fallback.

## Useful commands

```bat
npm run typecheck
npm run build
npm run preview
```

## Project structure
- `src/` — React application, pages/components, data and local persistence
- `supabase/migrations/` — database schema and RLS policies
- `supabase/seed.sql` — initial topic seed data
- `supabase/functions/ai-tutor/` — secure AI tutor Edge Function
- `.env.example` — environment configuration template

## Verification status
The archive includes the complete source tree and package manifest. Dependency installation could not be completed in the build environment because the package registry request timed out; therefore a production build and browser runtime have not been verified here. Run `npm install`, then `npm run typecheck` and `npm run build` on a network-connected machine.
