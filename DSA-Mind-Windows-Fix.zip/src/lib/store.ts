import { createClient, SupabaseClient } from '@supabase/supabase-js'; import type {Attempt,Topic} from './data';
const url=import.meta.env.VITE_SUPABASE_URL as string|undefined, key=import.meta.env.VITE_SUPABASE_ANON_KEY as string|undefined;
export const connected=import.meta.env.VITE_APP_MODE==='connected' && !!url && !!key;
export const supabase:SupabaseClient|null=connected?createClient(url!,key!):null;
const read=(k:string)=>{try{return JSON.parse(localStorage.getItem(k)||'[]')}catch{return []}};
export const getAttempts=():Attempt[]=>read('dsa-mind-attempts');
export function saveAttempt(a:Attempt){const all=[a,...getAttempts()];localStorage.setItem('dsa-mind-attempts',JSON.stringify(all)); if(supabase) void supabase.from('assessments').insert({topic:a.topic,round:a.round,score:a.score,total:a.total,weak_concepts:a.weak});}
export const getUser=()=>localStorage.getItem('dsa-mind-user')||'Learner';
export function setUser(name:string){localStorage.setItem('dsa-mind-user',name);}
export function signOut(){localStorage.removeItem('dsa-mind-user');}
