create extension if not exists pgcrypto;
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, display_name text, created_at timestamptz default now());
create table if not exists public.topics (id uuid primary key default gen_random_uuid(), name text unique not null, description text);
create table if not exists public.questions (id uuid primary key default gen_random_uuid(), topic_id uuid references public.topics(id), concept text not null, prompt text not null, options jsonb not null, correct_option integer not null check(correct_option between 0 and 3), explanation text, gap_type text);
create table if not exists public.assessments (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade default auth.uid(), topic text not null, round integer not null default 1, score integer not null, total integer not null, weak_concepts text[] default '{}', created_at timestamptz default now());
create table if not exists public.assessment_responses (id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.assessments(id) on delete cascade, question_id uuid references public.questions(id), selected_option integer, is_correct boolean not null);
create table if not exists public.learning_gaps (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade default auth.uid(), topic text not null, concept text not null, gap_type text not null, occurrences integer not null default 1, updated_at timestamptz default now(), unique(user_id,topic,concept));
insert into public.topics(name,description) values ('Arrays','Indexing, traversal and common patterns'),('Strings','String operations and patterns'),('Linked Lists','Nodes, traversal and pointer updates') on conflict(name) do nothing;
alter table public.profiles enable row level security; alter table public.assessments enable row level security; alter table public.assessment_responses enable row level security; alter table public.learning_gaps enable row level security;
create policy "profile owner read" on public.profiles for select using (auth.uid()=id);
create policy "profile owner update" on public.profiles for update using (auth.uid()=id);
create policy "profile owner insert" on public.profiles for insert with check (auth.uid()=id);
create policy "assessment owner all" on public.assessments for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "response owner all" on public.assessment_responses for all using (exists(select 1 from public.assessments a where a.id=assessment_id and a.user_id=auth.uid())) with check (exists(select 1 from public.assessments a where a.id=assessment_id and a.user_id=auth.uid()));
create policy "learning gap owner all" on public.learning_gaps for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
-- Topics and question bank are readable by authenticated users.
alter table public.topics enable row level security; alter table public.questions enable row level security;
create policy "topics readable" on public.topics for select to authenticated using (true);
create policy "questions readable" on public.questions for select to authenticated using (true);
