// Deploy with: supabase functions deploy ai-tutor
// Set secret: supabase secrets set GEMINI_API_KEY=your_key
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors() });
  try {
    const { concept, topic } = await req.json();
    const key = Deno.env.get('GEMINI_API_KEY');
    if (!key) return Response.json({ error: 'GEMINI_API_KEY is not configured' }, { status: 503, headers: cors() });
    const prompt = `Teach a beginner the DSA concept "${concept}" in the topic "${topic}". Return clear sections: Simple definition, Beginner explanation, Step-by-step example, Code example in JavaScript, Common mistakes, Short summary. Be accurate and concise.`;
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({contents:[{parts:[{text:prompt}]}]}) });
    const data = await response.json();
    if (!response.ok) return Response.json({ error: data.error?.message || 'Gemini request failed' }, { status: 502, headers: cors() });
    return Response.json({ text: data.candidates?.[0]?.content?.parts?.map((p: {text?:string})=>p.text||'').join('\n') || 'No explanation was generated.' }, { headers: cors() });
  } catch { return Response.json({ error:'Invalid request' }, {status:400,headers:cors()}); }
});
function cors(){return {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};}
