-- Optional question seed. Frontend demo mode ships with a complete local question bank.
insert into public.topics(name,description) values ('Arrays','Array fundamentals'),('Strings','String fundamentals'),('Linked Lists','Linked list fundamentals') on conflict(name) do nothing;
